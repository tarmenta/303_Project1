#include <iostream>
#include <utility>
#include "Node.h"

using namespace std;


int main()
{


	pair <int,int> arry [10];

	struct node* cityA = newNode("A");
	struct node* cityB = newNode("B");
	struct node* cityC = newNode("C");
	struct node* cityD = newNode("D");
	struct node* cityE = newNode("E");
	struct node* cityF = newNode("F");
	struct node* cityG = newNode("G");

	cityA->one = cityB;
	cityA->two = cityE;
	cityA->three = cityG;


	

	
	
	
	

	return 0;
}