#pragma once
#include<string>

using namespace std;

struct node
{
	string name;


	struct node* one;

	struct node* two;

	struct node* three;
};

struct node* newNode(string Data)
{
	// Allocate memory for new node  

	struct node* node = new struct node;
	// Assign data to this node 
	node->name = Data;
	
	// Initialize left and right children as NULL 
	node->one = NULL;
	node->two = NULL;
	node->three = NULL;

	return(node);
}